package com.pcassem.www.huaweithyj.entity;

import java.io.Serializable;

/**
 * Created by zhangqi on 2017-07-18.
 */
public class BaseEntity implements Serializable {
}
