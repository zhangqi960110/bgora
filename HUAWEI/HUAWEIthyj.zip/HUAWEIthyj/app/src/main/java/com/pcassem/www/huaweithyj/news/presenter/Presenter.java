package com.pcassem.www.huaweithyj.news.presenter;

public interface Presenter {
    void onCreate();

    void onStop();
}
